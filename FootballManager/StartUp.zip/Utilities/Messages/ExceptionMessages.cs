﻿namespace FootballManager.Utilities.Messages
{
    public class ExceptionMessages
    {
        public const string ManagerNameNull = "Manager's name cannot be null or empty.";
        public const string TeamNameNull = "Team name cannot be null or empty.";
    }
}
