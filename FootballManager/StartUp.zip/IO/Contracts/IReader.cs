﻿namespace FootballManager.IO.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
